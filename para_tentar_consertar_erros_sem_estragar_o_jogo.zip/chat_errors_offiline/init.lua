-- Filtro Silencioso de Chat e Logs para o Terras Abertas 4.0.0 PreDev

minetest.register_on_chat_message(function(name, message)
    if message:find("NodeResolver: failed to resolve node name") or 
       message:find("failed to resolve node name 'default:") or
       message:find("ERROR%[Emerge") then
        return true 
    end
end)

if minetest.features and minetest.features.chat_send_all then
    local original_send = minetest.chat_send_all
    minetest.chat_send_all = function(text)
        if text:find("failed to resolve node name") or text:find("default:") then
            return 
        end
        return original_send(text)
    end
end
